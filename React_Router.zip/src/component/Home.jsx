import React from "react";

function Home() {
  return <h1>Welcome to the world of Geeks!</h1>;
}

export default Home;
